/*
* step 1
*/

// const mongoose = require('mongoose');

// let _db;

// const USERNAME = 'mayank';
// const PASSWORD = 'qwerty123'; // When entering your password, make sure that any special characters are URL encoded.
// const DATABASE_NAME = 'netflix';

// const MONGODB_URI = `mongodb+srv://${USERNAME}:${PASSWORD}@cluster0-6egvr.mongodb.net/${DATABASE_NAME}?retryWrites=true&w=majority`;

// const mongoConnect = (callback) => {
//     mongoose.connect(MONGODB_URI , { useNewUrlParser: true,  useUnifiedTopology: true })
//     .then(() => {
//         console.log('MongoDB Connected!');
//         callback();
//     })
//     .catch(err => {
//         console.log(err);
//         throw err;
//     });
// };

// const getDb = () => {
//     if(_db) {
//         return _db;
//     }
//     throw 'No database found!';
// }

// exports.mongoConnect = mongoConnect;
// exports.getDb = getDb;