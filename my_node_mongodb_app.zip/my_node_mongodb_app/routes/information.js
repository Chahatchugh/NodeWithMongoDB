const express = require('express');
const informationController = require('../controllers/information');
const isAuth = require('../middleware/is-auth');             
const { check, body } = require('express-validator');
const router = express.Router();
const User = require('../models/information');
router.get('/', informationController.getInformation);
router.post('/', [
    check('userEmail') // checks every where(body, params, header)
        .isEmail()
        .withMessage('Please enter a valid email')
        .custom((value, {req}) => {
            return User.findOne({email: value})
            .then(userDoc => {
              if(userDoc) {
                return Promise.reject('E-Mail already registered, please use another email');
              }
        }) })
        .normalizeEmail(),
    body('password', 'Please enter password>=5 && Alphanumeric') // only checks in body
        .isLength({min: 5})
        .isAlphanumeric()
        .trim(),
    // body('confirmPassword')
    //     .custom((value, {req}) => {
    //         if(value !== req.body.password) 
    //             throw new Error('Passwords does not match!');
    //     })
    //     .trim()
    ], informationController.postSignUpInformation);
router.post('/netflix', informationController.postInformation);
router.get('/logout', informationController.logout)
router.get('/forgotPassword', informationController.getForgotPassword)
router.post('/forgotPassword', informationController.postForgotPassword)
router.get('/forgotPassword/:token', informationController.getNewPassword);
router.post('/newPassword', informationController.postNewPassword);
router.get('/movies' , informationController.getMovies);
router.post('/watchedList' ,isAuth, informationController.postWatchedList)
router.get('/watchedList' ,isAuth , informationController.getWatchedList)
router.get('/movies/:movieId', informationController.getDetail);
router.post('/watched-delete-item',isAuth , informationController.postWatchedDeleteItem)
router.get('/addMovie', isAuth , informationController.getAddMovie);
router.post('/addMovie', isAuth , informationController.postAddMovie);
router.get('/addMovie/:movieId', isAuth , informationController.getEditMovie);
router.post('/editMovie', isAuth , informationController.postEditMovie);
router.post('/deleteMovie' , isAuth , informationController.postDeleteMovie)
router.get('/movieDetail/:movieId', isAuth, informationController.getPdf);

module.exports = router;