const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const User = require('./models/information');
const mongoose = require('mongoose');
//const mongoConnect = require('./util/database').mongoConnect; 
const informationController = require('./controllers/information');        
const isAuth = require('./middleware/is-auth');            
const expressHbs = require('express-handlebars');
const informationRoute = require('./routes/information');
const session = require('express-session');                                          
const MongoDBStore = require('connect-mongodb-session')(session);                     
const multer = require('multer');                   // file parser
const csrf = require('csurf');                      //Cross-Site Request Forgery (CSRF) 
const flash = require('connect-flash');             

const USERNAME = 'mayank';                                               
const PASSWORD = 'qwerty123';                                            
const DATABASE_NAME = 'netflix';                                         

const MONGODB_URI = `mongodb+srv://${USERNAME}:${PASSWORD}@cluster0-6egvr.mongodb.net/${DATABASE_NAME}?retryWrites=true&w=majority`; 

const store = new MongoDBStore({                                        
  uri: MONGODB_URI,
  collection: 'sessions'
});
//const csrfProtection = csrf();                     
const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
      cb(null, 'images'); //null tells its ok to store the file( i.e the file is ok)
  },
  filename: (req, file, cb) => {
      cb(null, `${new Date().toISOString()}-${file.originalname}`);
  }
});
const fileFilter = (req, file, cb) => {
  if(['image/png','image/jpg','image/jpeg'].includes(file.mimetype)) {
      cb(null, true) //to store the file
  } else {
      cb(null, false) // to not store the file
  }
}

app.set('view engine', 'ejs');
app.set('views', 'views');
app.engine('hbs', expressHbs({ layoutsDir: 'views/layouts/', defaultLayout: 'main-layout', extname: 'hbs' }));
app.set('view engine', 'hbs');
app.set('views', 'views'); 
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/images',express.static(path.join(__dirname, 'images')));
app.use(multer({storage: fileStorage, fileFilter: fileFilter}).single('url')); // Advance Configuration to save file(storage) and filter files(fileFilter)

app.use(                                                                   
    session({
      secret: 'my secret',
      resave: false,
      saveUninitialized: false,
      store: store
    })
  );

//added here because of CSRF issue. As CSRF is not available in the stripe(payment gateway) form.
app.post('/create-order', isAuth, informationController.postPayment)

// app.use(csrfProtection);                          
app.use(flash());                                 

app.use((req, res, next) => {
    if (!req.session.user) {
        return next();
      }
      User.findById(req.session.user._id)                                    
    //User.findById('5dcbbdd85fbf397135bc62ce')                         
    .then(user => {
        req.user = user;
        next();
    })
    .catch(err => console.log(err));
});

app.use((req, res, next) => {                                               
    res.locals.isAuthenticated = req.session.isLoggedIn;
    // res.locals.csrfToken = req.csrfToken();
    next();
  }); 

app.use(informationRoute);
app.use('/500',informationController.get500);
app.use((req, res, next) => {
    res.status(404).render('404', { pageTitle: 'Page Not Found', path: '' , isAuthenticated: req.session.isLoggedIn });   

})

app.use('/500',(error, req, res, next) => {
  res.status(500).render('500', { 
      pageTitle: 'Error', 
      isLoggedIn: req.session.isLoggedIn 
  })});


// mongoConnect(() => {                                                
//     User.findOne().then(user => {
//         if(!user) {
//             const user = new User({
//                 name: 'chahat',
//                 email: 'chahatchugh@gmail.com',
//                 watchedList:{
//                     movies:[]
//                 }
//             });
//             user.save();
//         }
//     });
//     app.listen(8080);
// });

mongoose                                                                           
  .connect(MONGODB_URI , { useNewUrlParser: true,  useUnifiedTopology: true })
  .then(result => {
    console.log('MongoDB Connected!');
    User.findOne().then(user => {

      if (!user) {
        // const user = new User({
        //   email: 'Chahat.chugh@kelltontech.com',
        //   password: 'chahat',
        //   watchedList: {
        //     movies: []
        //   }
        // });
        // user.save();
      }
    });
    app.listen(8080);
  })
  .catch(err => {
    console.log(err);
  });
