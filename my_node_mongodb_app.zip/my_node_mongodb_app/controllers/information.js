const Information = require('../models/information');
const Movies = require('../models/movies');
const bcrypt = require('bcryptjs');
var nodemailer = require('nodemailer');
var nodemailerTransport = require('nodemailer-sendgrid-transport');
const crypto = require('crypto');
const fileHelper = require('../util/file');
const { validationResult } = require('express-validator');
const path = require('path');
const fs = require('fs');
const PDFDocument = require('pdfkit');
const stripe = require('stripe')('sk_test_CbcGe7IuJXfagpfAOWOqfkUC00Bd7KQHUS');
const ITEMS_PER_PAGE = 1;
var options = {
  auth: {
      api_key: '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'
  }
}
var mailer = nodemailer.createTransport(nodemailerTransport(options));

exports.getInformation = (req, res, next) => {
  let message = req.flash('error');
  if (message.length > 0) {
    message = message[0];
  } else {
    message = null;
  }
  res.render('information/index', { pageTitle: 'Information', path:'/', errorMessage: message})
  //   Information.find()
  //   .then((info) => {
  //     res.render('information/index', { prods: info, pageTitle: 'Information', path:'/' , isAuthenticated: false});   

  //   })
  // .catch(err => console.log(err));
  };

exports.postInformation =(req, res, next) => {
  var userEmail = req.body.userEmail;
  var password = req.body.password
  // Information.findById('5dcbbdd85fbf397135bc62ce')  
  Information.findOne({ email: userEmail })              
    .then(user => {
      if(!user) {
        req.flash('error', 'Invalid email or password.');
        return res.redirect('/');
      }
      // req.session.isLoggedIn = true;
      // req.session.user = user;
      // req.session.save(err => {
      //   console.log(err);
       // res.render('information/netflix', { pageTitle: 'Information', path:'/' , userName: userName});
        
  //});
  bcrypt
        .compare(password, user.password)
        .then(doMatch => {

          if (doMatch) {
            req.session.isLoggedIn = true;
            req.session.user = user;
            return req.session.save(err => {
              //res.redirect('/');
              res.render('information/netflix', { pageTitle: 'Information', path:'/' , userEmail: userEmail})
            });
          }
          else{
            req.flash('error', 'Invalid email or password.');
            res.redirect('/')
          }
        })
})
.catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
}
  //console.log(err)
  );
}

exports.getMovies = (req, res, next) => {
  const page = +req.query.page || 1;
  let totalItems;
  Movies.find().countDocuments().then(numMovies => {
    totalItems = numMovies;
    return Movies.find() // returns a curser
    .skip((page - 1) * ITEMS_PER_PAGE) // skips previous data
    .limit(ITEMS_PER_PAGE) // limits data
})
  .then((info) => {
    const watch =req.user
   // res.render('information/movies', { movies: info, pageTitle: 'Information', path:'/' ,  hasInfo: info.length > 0 , isAuthenticated: req.session.isLoggedIn });  
   res.render('information/movies', { 
   movies: info,
   pageTitle: 'Information', 
   path:'/' ,  
   hasInfo: info.length > 0 ,
   currentPage: page,
   hasNextPage: ITEMS_PER_PAGE * page < totalItems,
   hasPreviousPage: page > 1,
   nextPage: page + 1,
   previousPage: page - 1,
   lastPage: Math.ceil(totalItems/ ITEMS_PER_PAGE)}) 
  })
.catch(err => console.log(err));

};

exports.postWatchedList =(req, res, next) => {
  const movieId = req.body.id;
  Movies.findById(movieId)
  .then(result => {
      return req.user.addToWatchedList(result);
  })
  .then(() => {
      res.redirect('/watchedList');
  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
  }
    //console.log(err)
    )
}

exports.getWatchedList = (req, res, next) => {
req.user.populate('watchedList.movies.movieId')
    .execPopulate() // converts populate into a promise
    .then(user => {
        const movies = user.watchedList.movies;
        res.render('information/watchedList', { movies: movies, pageTitle: 'Information', path:'/' ,  hasInfo: movies.length > 0 });
    })
    .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
      //console.log(err)
      );
};

exports.getDetail = (req , res , next) =>{
  const movieId = req.params.movieId;
  Movies.findById(movieId).then(movie => {
      res.render('information/detail', { movies: movie, pageTitle: movie.title, path: '/movies' });
  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
  }
    //console.log(err)
    );
}

exports.postWatchedDeleteItem = (req , res , next) =>{
  const movieId = req.body.id;
  req.user.removeFromWatchedList(movieId)
  .then(result => {
      res.redirect('/watchedList')
  })
  .catch(err => {
    const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
    //console.log(err)
    )
}

exports.getAddMovie = (req , res , next) =>{
  //res.render('information/addMovie', { pageTitle: 'Add Movie', path: '/', editing: false , isAuthenticated: req.session.isLoggedIn });  
  res.render('information/addMovie', { pageTitle: 'Add Movie', path: '/', editing: false }) 
}

exports.postAddMovie = (req, res , next) =>{
  const userId = req.user;
  const movieName = req.body.movieName;
  const urlImg = req.file;
  if (!urlImg)  return res.status(422).render('500');

  const url = urlImg.path;
  const movies = new Movies({
    movieName: movieName,
    url: url,
    userId: userId // Automatically adds only _id from User object
  });
  movies.save()
  .then(result => {
      res.redirect('/movies');        
  }).catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
      //console.log(err)
  });
}

exports.getEditMovie = (req , res , next) =>{
  const editMode = req.query.edit;
  if(!editMode) {
      res.redirect('/');
  }
  const movieId= req.params.movieId;
  Movies.findById(movieId)
  .then(movie => {
      if(!movie) return res.redirect('/')
      // res.render('information/addMovie', { pageTitle: 'Edit Movie', path: '/', editing: editMode, movies: movie ,isAuthenticated: req.session.isLoggedIn });       //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> step2
      res.render('information/addMovie', { pageTitle: 'Edit Movie', path: '/', editing: editMode, movies: movie })   //======================>step3
    })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
    //console.log(err)
    );
}

exports.postEditMovie = (req , res , next)=>{
  const movieId = req.body.id;
  const movieNameUpdated = req.body.movieName;
  const urlUpdated = req.file;
  Movies.findById(movieId)
  .then(movie => {
    movie.movieName = movieNameUpdated;
    // movie.url = urlUpdated;
    if (urlUpdated) {
      fileHelper.deleteFile(movie.url);
      movie.url = urlUpdated.path;
    }
      return movie.save();
  })
  .then(result => {
      res.redirect('/movies');
  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
    //console.log(err)
    );
}

exports.postDeleteMovie = (req , res , next) =>{
  const movieId = req.body.id;
  Movies.findOne({_id: movieId})
  .then((movie)=>{
    fileHelper.deleteFile(movie.url);
    return Movies.deleteOne({_id: movieId })
  })
  .then(result => {
      req.user.removeFromWatchedList(movieId)
      res.redirect('/movies');    

  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
    //console.log(err)
    );
}

exports.logout = (req, res, next) => {
  req.session.destroy(err => {
    res.redirect('/');
  });
};

exports.postSignUpInformation = (req, res, next) => {
  const userEmail = req.body.userEmail;
  const password = req.body.password;
  var emailSent = {
    to: userEmail,
    from: 'chahat.chugh@kelltontech.com',
    subject: 'Signed up successfully',
    text: 'Congratulations ! Signed up successfully',
    html: '<b>Congratulations ! Signed up successfully</b>'
  };
  const errors = validationResult(req);
  if(!errors.isEmpty()) {
    return res.status(422).render('information/index', {
      path: '/',
      pageTitle: 'Signup',
      errorMessage: errors.array()[0].msg,
      //oldInput: oldInput
      // isLoggedIn: req.session.isLoggedIn
    });
  }
  // Information.findOne({ email: userEmail })
  //   .then(userDoc => {
  //     if (userDoc) {
  //       req.flash('error', 'E-Mail exists already, please pick a different one.');
  //       return res.redirect('/');
  //     }
      //return
       bcrypt
        .hash(password, 12)
        .then(hashedPassword => {
          const user = new Information({
            email: userEmail,
            password: hashedPassword,
            watchedList: { movies: [] }
          });
          return user.save();
        })
        .then(result => {
          res.redirect('/');
          mailer.sendMail(emailSent, function(err, res) {
            if (err) { 
                console.log(err) 
            }
            console.log(res , "signed up");
          });
        });
        
    // })
    // .catch(err => {
    //   console.log(err);
    // });
};

exports.getForgotPassword = (req,res,next) =>{
  let message = req.flash('error');
  if (message.length > 0) {
    message = message[0];
  } else {
    message = null;
  }
  res.render('information/forgotPassword', { pageTitle: 'Forgot Password', path:'/', errorMessage: message})
}

exports.postForgotPassword = (req,res,next) =>{
  const userEmail = req.body.userEmail;
  crypto.randomBytes(32, (err, buffer) => {
    if(err) {
      console.log(err);
      return res.redirect('/forgotPassword');
    }
    const token = buffer.toString('hex');
    Information.findOne({email: userEmail})
    .then(user => {
      if(!user) {
        req.flash('error', 'No account found');
        return res.redirect('/forgotPassword');
      }
      user.resetToken = token;
      user.resetTokenExpiration = Date.now() + 3600000;
      return user.save();
    })
    .then(result => {
      res.redirect('/');
      var emailSent = {
        to: userEmail,
        from: 'chahat.chugh@kelltontech.com',
        subject: 'Password reset',
        html: `
          <p>You requested a password reset</p>
          <p>click this <a href='http://localhost:8080/forgotPassword/${token}'>link</a> to set a new password</p>
        `
      };
      mailer.sendMail(emailSent, function(err, res) {
        if (err) { 
            console.log(err) 
        }
        console.log(res , "reset link");
      });
    })
    .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    }
      //console.log(err)
      );
  });
}

exports.getNewPassword = (req, res, next) => {
  const token = req.params.token;
  Information.findOne({resetToken: token, resetTokenExpiration: {$gt: Date.now()}})
  .then(user => {
    let message = req.flash('error');
    message = message.length > 0 ? message[0] : null
    res.render('information/newPassword', { 
      pageTitle: 'New Password', 
      path: 'information/newPassword',
      errorMessage: message,
      userId: user._id.toString(),
      passwordToken: token
      // isLoggedIn: req.session.isLoggedIn 
    });
  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
  }
    //console.log(err)
    );
};

exports.postNewPassword = (req, res, next) => {
  const newPassword = req.body.password;
  const userId = req.body.userId;
  const passwordToken = req.body.passwordToken;
  let resetUser;
  console.log("userId" , userId)
  Information.findOne({
    resetToken: passwordToken,
    resetTokenExpiration: { $gt: Date.now() },
    _id: userId
  }).then(user => {
    resetUser = user;
    return bcrypt.hash(newPassword, 12)
  })
  .then(hashedPassword => {
    resetUser.password = hashedPassword;
    resetUser.resetToken = null;
    resetUser.resetTokenExpiration = undefined;
    return resetUser.save();
  })
  .then(result => {
    res.redirect('/');
  })
  .catch(err => {
      const error = new Error(err);
      error.httpStatusCode = 500;
      return next(error);
    //console.log(err);
  });
};

exports.get500 = (req, res, next) => {
  res.status(500).render('500', { 
      pageTitle: 'Error', 
      isLoggedIn: req.session.isLoggedIn 
  });
}


exports.getPdf = (req, res, next) => {
  const movieId = req.params.movieId;
  Movies.findById(movieId)
  .then((movie) => {
      if(!movie) 
          return next(new Error('No order Found'));
      // if(movie.user.id.toString() !== req.user._id.toString()) USER SPECIFIC MOVIES
      //     return next(new Error('Unauthorized'));
      const movieName = `movie-${movieId}.pdf`;
      const moviePath = path.join('data','movie', movieName);

      const pdfDoc = new PDFDocument();
      res.setHeader('Content-Type','application/pdf');
      res.setHeader('Content-Disposition', `inline; filename="${movieName}"`)  // change inline to attachment to download on click
     
      pdfDoc.pipe(fs.createWriteStream(moviePath)); // creates the file to invoicePath
      pdfDoc.pipe(res) // returns pdf to client

      pdfDoc.fontSize(26).text('movie', {
          underline: true
      });

      pdfDoc.end();
      //fails for larger files
      // fs.readFile(invoicePath, (err, data) => {
      //     if(err) return next(err);
      //     res.setHeader('Content-Type','application/pdf');
      //     res.setHeader('Content-Disposition', `inline; filename="${invoiceName}"`)  // change inline to attachment to download on click
      //     res.send(data);
      // });

      //streams don't load data in the node memory and it is the optimized way to do it. 
      // const file = fs.createReadStream(invoicePath);
      // res.setHeader('Content-Type','application/pdf');
      // res.setHeader('Content-Disposition', `inline; filename="${invoiceName}"`)  // change inline to attachment to download on click
      // file.pipe(res);

  })
  .catch(err => next(err));
  
}

exports.postPayment = (req, res, next) => {
  const token = req.body.stripeToken;
  console.log(token , "token")
  // req.user.populate('watchedList.movies.movieId')
  // .execPopulate()
  // .then(user => {
  //     user.cart.items.forEach(p => {
  //         totalSum += p.quantity * p.productId.price;
  //     })
  //     const products = user.cart.items.map(p => {
  //         return { quantity: p.quantity, product: { ...p.productId._doc }};
  //     });
  //     const order = new Order({
  //         user: {
  //             email: req.user.email,
  //             userId: req.user
  //         },
  //         products: products
  //     });
  //     return order.save();
  // })    
  // .then(result => {
      const charge = stripe.charges.create({
          amount: 100,
          shipping: {
              name: 'req.user.email',
              address: {
                line1: '510 Townsend St',
                postal_code: '98140',
                city: 'San Francisco',
                state: 'CA',
                country: 'US',
              }
            },
          currency: 'usd',
          description: 'shop demo order',
          source: token,
          metadata: {order_id : '5+656' }
      });
      console.log(charge,'charge - stripe')
  // })
  // .then(result => {
      res.redirect('/movies');
  // })
  // .catch(err => console.log(err));
}

