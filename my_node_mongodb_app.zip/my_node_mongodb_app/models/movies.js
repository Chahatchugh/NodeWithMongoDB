const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const UserSchema = new Schema({
    movieName: {
        type: String,
        required: true
    }, 
    url:{
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Movies', UserSchema);
