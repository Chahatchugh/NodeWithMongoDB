const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const UserSchema = new Schema({
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }, 
    resetToken: String,
    resetTokenExpiration: Date,
    watchedList:{
        movies: [{
            movieId: { 
                type: Schema.Types.ObjectId, 
                required: true,
                ref: 'Movies'
            }
        }]
    }
});

UserSchema.methods.addToWatchedList = function(movie) {
    const cartProductIndex = this.watchedList.movies.findIndex(cp => {

        return cp.movieId.toString() === movie.id.toString();
    });

    const updatedWatchedListItem = [...this.watchedList.movies];

    const movieId = movie.id

    if(cartProductIndex>= 0)
    {
    updatedWatchedListItem
    }
    else
    {
    updatedWatchedListItem.push({ movieId : movieId})
    }
    this.watchedList = {
        movies: updatedWatchedListItem
    }
    return this.save()
}

UserSchema.methods.removeFromWatchedList = function(movieId) {
    const updatedWatchedListItem = this.watchedList.movies.filter(item => {
        return item.movieId.toString() !== movieId.toString();
    });
    this.watchedList.movies = updatedWatchedListItem;
    return this.save();
}

module.exports = mongoose.model('User', UserSchema);
